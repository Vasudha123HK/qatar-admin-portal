from datetime import datetime, date

from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

db = SQLAlchemy()


class Admin(UserMixin, db.Model):
    __tablename__ = "admin"

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)

    opportunities = db.relationship(
        "Opportunity",
        backref="creator",
        lazy="dynamic",
        cascade="all, delete-orphan",
    )

    def set_password(self, plain: str) -> None:
        self.password_hash = generate_password_hash(plain)

    def check_password(self, plain: str) -> bool:
        return check_password_hash(self.password_hash, plain)


class Opportunity(db.Model):
    __tablename__ = "opportunity"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    duration = db.Column(db.String(100), nullable=True)
    start_date = db.Column(db.Date, nullable=True)
    description = db.Column(db.Text, nullable=True)
    skills = db.Column(db.String(500), nullable=True)
    category = db.Column(db.String(100), nullable=False)
    future_opportunities = db.Column(db.Boolean, default=False, nullable=False)
    max_applicants = db.Column(db.Integer, nullable=True)
    admin_id = db.Column(db.Integer, db.ForeignKey("admin.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def as_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "title": self.name,
            "duration": self.duration,
            "start_date": self.start_date.isoformat()
            if isinstance(self.start_date, date)
            else None,
            "description": self.description,
            "skills": self.skills,
            "category": self.category,
            "future_opportunities": bool(self.future_opportunities),
            "futureOpportunities": bool(self.future_opportunities),
            "max_applicants": self.max_applicants,
            "maxApplicants": self.max_applicants,
            "admin_id": self.admin_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
