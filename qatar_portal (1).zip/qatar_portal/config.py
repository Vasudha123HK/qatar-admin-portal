import os


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY") or "dev-change-in-production-use-env"
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL") or "sqlite:///qf_admin.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SESSION_COOKIE_SECURE = False
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 24 * 14  # 14 days when "remember me"
    WTF_CSRF_ENABLED = False

    PASSWORD_RESET_SALT = "password-reset-v1"

    ALLOWED_OPPORTUNITY_CATEGORIES = frozenset(
        (
            "Technology",
            "Business",
            "Education",
            "Arts",
            "Healthcare",
            "Volunteer",
            "Internship",
            "Research",
            "Government",
            "Other",
        )
    )

