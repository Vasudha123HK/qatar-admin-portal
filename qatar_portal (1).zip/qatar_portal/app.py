import logging

from flask import Flask
from flask_login import LoginManager

from config import Config
from models import Admin, db
from routes import register_routes


def create_app(config_class=None):
    config_class = config_class or Config
    flask_app = Flask(__name__, static_folder="static", template_folder="templates")
    flask_app.config.from_object(config_class)

    db.init_app(flask_app)

    login_manager = LoginManager()
    login_manager.init_app(flask_app)
    login_manager.login_view = "login_form"
    login_manager.login_message = None

    @login_manager.user_loader
    def load_user(uid):
        if uid is None:
            return None
        try:
            return Admin.query.get(int(uid))
        except (TypeError, ValueError):
            return None

    register_routes(flask_app, login_manager)

    with flask_app.app_context():
        db.create_all()

    if not flask_app.logger.handlers:
        logging.basicConfig(level=logging.INFO)

    return flask_app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
