import logging
from datetime import datetime
from typing import Any, Dict, Optional, Tuple, Union

from email_validator import EmailNotValidError, validate_email
from flask import jsonify, redirect, render_template, request, session, url_for
from flask_login import current_user, login_required, login_user, logout_user
from itsdangerous import URLSafeTimedSerializer
from config import Config
from models import Admin, Opportunity, db

log = logging.getLogger(__name__)


def _serializer(flask_app):
    return URLSafeTimedSerializer(
        secret_key=flask_app.config["SECRET_KEY"],
        salt=flask_app.config["PASSWORD_RESET_SALT"],
    )


def _opportunity_payload_valid(flask_app, data: Dict[str, Any]) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    cats = flask_app.config.get(
        "ALLOWED_OPPORTUNITY_CATEGORIES",
        Config.ALLOWED_OPPORTUNITY_CATEGORIES,
    )
    name = (data.get("name") or "").strip()
    if not name:
        return None, "Name is required"

    cat = (data.get("category") or "").strip()
    if cat not in cats:
        return None, f"Category must be one of: {', '.join(sorted(cats))}"

    mx_raw = data.get("max_applicants")
    try:
        max_applicants = int(mx_raw) if mx_raw not in (None, "") else None
    except (TypeError, ValueError):
        return None, "max_applicants must be an integer"

    op_kwargs = dict(
        name=name,
        duration=data.get("duration"),
        start_date=_parse_date(data.get("start_date")),
        description=data.get("description"),
        skills=data.get("skills"),
        category=cat,
        future_opportunities=_parse_future(data.get("future_opportunities")),
        max_applicants=max_applicants,
    )
    return op_kwargs, None


def _parse_date(raw):
    if raw is None or raw == "":
        return None
    if hasattr(raw, "year") and hasattr(raw, "month") and hasattr(raw, "day"):
        return raw
    s = str(raw).strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def _parse_future(val):
    if val is None:
        return False
    if isinstance(val, bool):
        return val
    s = str(val).strip().lower()
    return s in ("1", "true", "yes", "on")


def _normalize_payload(raw: dict | None) -> dict:
    if not raw:
        return {}
    pairs = (
        ("full_name", ("full_name", "fullName")),
        ("email", ("email",)),
        ("password", ("password",)),
        (
            "confirm_password",
            ("confirm_password", "confirmPassword", "password_confirm"),
        ),
        ("remember_me", ("remember_me", "rememberMe", "remember")),
        ("name", ("name", "title")),
        ("duration", ("duration",)),
        ("start_date", ("start_date", "startDate")),
        ("description", ("description",)),
        ("skills", ("skills",)),
        ("category", ("category",)),
        ("future_opportunities", ("future_opportunities", "futureOpportunities")),
        ("max_applicants", ("max_applicants", "maxApplicants")),
    )
    out = {}
    for canonical, aliases in pairs:
        for a in aliases:
            if a in raw and raw[a] is not None:
                out[canonical] = raw[a]
                break
    return out


def _merge_update(flask_app, existing: Opportunity, raw_incoming: Dict[str, Any]) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    base = {
        "name": existing.name,
        "duration": existing.duration,
        "start_date": existing.start_date,
        "description": existing.description,
        "skills": existing.skills,
        "category": existing.category,
        "future_opportunities": existing.future_opportunities,
        "max_applicants": existing.max_applicants,
    }
    upd = _normalize_payload(raw_incoming or {})
    for k in list(base.keys()):
        if k in upd and upd[k] is not None:
            base[k] = upd[k]
    pk, err = _opportunity_payload_valid(flask_app, base)
    return pk, err


def register_routes(flask_app, login_manager):

    @login_manager.unauthorized_handler
    def _unauthorized():
        if "/opportunities" in request.path or request.path.startswith("/api/"):
            return jsonify({"error": "Authentication required"}), 401
        if (
            request.accept_mimetypes.best_match(["application/json", "text/html"])
            == "application/json"
        ):
            return jsonify({"error": "Authentication required"}), 401
        return redirect(url_for("login_form"))

    @flask_app.route("/")
    def index_page():
        return render_template("index.html")

    @flask_app.route("/login", methods=["GET"])
    def login_form():
        if current_user.is_authenticated:
            return redirect(url_for("dashboard_form"))
        return render_template("login.html")

    @flask_app.route("/dashboard", methods=["GET"])
    @login_required
    def dashboard_form():
        return render_template("dashboard.html")

    # --- Authentication ---

    def _signup():
        raw = request.get_json(silent=True) or {}
        data = _normalize_payload(raw)

        fn = (data.get("full_name") or "").strip()
        email = data.get("email")
        pwd = data.get("password") or ""
        confirm = data.get("confirm_password")
        if confirm is None:
            confirm = pwd

        if not fn or not email:
            return jsonify({"error": "Missing required fields"}), 400
        try:
            email_ok = validate_email(email, check_deliverability=False).normalized
        except EmailNotValidError:
            return jsonify({"error": "Invalid email address"}), 400

        if len(pwd) < 8:
            return jsonify({"error": "Password must be at least 8 characters"}), 400
        if pwd != confirm:
            return jsonify({"error": "Passwords do not match"}), 400

        if Admin.query.filter(db.func.lower(Admin.email) == email_ok.lower()).first():
            return jsonify({"error": "Email is already registered"}), 409

        admin = Admin(full_name=fn, email=email_ok.lower())
        admin.set_password(pwd)
        db.session.add(admin)
        db.session.commit()
        login_user(admin, remember=False)
        return (
            jsonify(
                {
                    "status": "success",
                    "message": "Account created",
                    "user": {
                        "id": admin.id,
                        "email": admin.email,
                        "full_name": admin.full_name,
                    },
                }
            ),
            201,
        )

    def _login():
        raw = request.get_json(silent=True) or {}
        data = _normalize_payload(raw)

        email = data.get("email")
        pwd = data.get("password")
        remember = bool(data.get("remember_me"))

        if not email or pwd is None:
            return jsonify({"error": "Invalid email or password"}), 401

        normalized = email.strip().lower()
        admin = Admin.query.filter(db.func.lower(Admin.email) == normalized).first()
        generic = {"error": "Invalid email or password"}

        if not admin or not admin.check_password(str(pwd)):
            return jsonify(generic), 401

        login_user(admin, remember=remember)
        session.permanent = remember

        return (
            jsonify(
                {
                    "status": "success",
                    "user": {
                        "id": admin.id,
                        "email": admin.email,
                        "full_name": admin.full_name,
                    },
                }
            ),
            200,
        )

    def _forgot_password():
        raw = request.get_json(silent=True) or {}
        data = _normalize_payload(raw)
        raw_email = (data.get("email") or "").strip().lower()

        admin = Admin.query.filter(db.func.lower(Admin.email) == raw_email).first()
        if admin:
            ser = _serializer(flask_app)
            token = ser.dumps({"uid": admin.id})
            prefix = request.url_root.rstrip("/") if request.url_root else ""
            simulated = f"{prefix}/reset-password?token={token}"
            log.warning(
                "[PASSWORD RESET] email=%s (simulated — no email sent). Link (1 hour): %s",
                admin.email,
                simulated,
            )

        always = {"status": "success", "message": "Check your inbox for instructions."}
        return jsonify(always), 200

    @flask_app.route("/signup", methods=["POST"])
    @flask_app.route("/api/signup", methods=["POST"])
    @flask_app.route("/register", methods=["POST"])
    @flask_app.route("/api/register", methods=["POST"])
    def signup():
        return _signup()

    @flask_app.route("/login", methods=["POST"])
    @flask_app.route("/api/login", methods=["POST"])
    def login_post():
        return _login()

    @flask_app.route("/logout", methods=["POST"])
    @flask_app.route("/api/logout", methods=["POST"])
    @login_required
    def logout():
        logout_user()
        return jsonify({"status": "success", "message": "Logged out"}), 200

    @flask_app.route("/forgot-password", methods=["POST"])
    @flask_app.route("/api/forgot-password", methods=["POST"])
    def forgot_password():
        return _forgot_password()

    # --- Opportunities (JSON) ---

    def _ensure_owner(row: Opportunity) -> Union[Opportunity, Tuple]:
        if row.admin_id != current_user.id:
            return (jsonify({"error": "Not found"}), 404)
        return row

    @flask_app.route("/opportunities", methods=["GET"])
    @flask_app.route("/api/opportunities", methods=["GET"])
    @login_required
    def list_opportunities():
        rows = Opportunity.query.filter_by(admin_id=current_user.id).order_by(
            Opportunity.created_at.desc()
        )
        return jsonify({"status": "success", "data": [o.as_dict() for o in rows]}), 200

    @flask_app.route("/opportunities", methods=["POST"])
    @flask_app.route("/api/opportunities", methods=["POST"])
    @login_required
    def create_opportunity():
        raw = request.get_json(silent=True) or {}
        data = _normalize_payload(raw)
        kw, err = _opportunity_payload_valid(flask_app, data)
        if err:
            return jsonify({"error": err}), 400

        row = Opportunity(admin_id=current_user.id, **kw)
        db.session.add(row)
        db.session.commit()
        return jsonify({"status": "success", "data": row.as_dict()}), 201

    @flask_app.route("/opportunities/<int:oid>", methods=["GET"])
    @flask_app.route("/api/opportunities/<int:oid>", methods=["GET"])
    @login_required
    def get_opportunity(oid):
        row = Opportunity.query.get_or_404(oid)
        check = _ensure_owner(row)
        if isinstance(check, tuple):
            return check
        return jsonify({"status": "success", "data": check.as_dict()}), 200

    def _save_update(row):
        db.session.commit()
        return jsonify({"status": "success", "data": row.as_dict(), "message": "Updated"}), 200

    @flask_app.route("/opportunities/<int:oid>", methods=["PUT"])
    @flask_app.route("/api/opportunities/<int:oid>", methods=["PUT"])
    @flask_app.route("/opportunities/<int:oid>/edit", methods=["POST", "PUT"])
    @flask_app.route("/api/opportunities/<int:oid>/edit", methods=["POST", "PUT"])
    @login_required
    def edit_opportunity(oid):
        row = Opportunity.query.get_or_404(oid)
        check = _ensure_owner(row)
        if isinstance(check, tuple):
            return check

        raw = request.get_json(silent=True) or {}
        kw, err = _merge_update(flask_app, row, raw)
        if err:
            return jsonify({"error": err}), 400

        for k, v in kw.items():
            setattr(row, k, v)
        return _save_update(row)

    @flask_app.route("/opportunities/<int:oid>", methods=["DELETE"])
    @flask_app.route("/api/opportunities/<int:oid>", methods=["DELETE"])
    @login_required
    def delete_opportunity(oid):
        row = Opportunity.query.get_or_404(oid)
        check = _ensure_owner(row)
        if isinstance(check, tuple):
            return check

        db.session.delete(row)
        db.session.commit()
        return jsonify({"status": "success", "message": "Deleted"}), 200
